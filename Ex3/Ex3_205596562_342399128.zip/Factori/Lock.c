/////////////////////////////////////////////////////////////////////////
//////////////////////////////// Lock.c /////////////////////////////////
/////////////////////////////////////////////////////////////////////////

//info: This Lock.c file of the Factori process is incharge for create
//      the Lock sturct and incharge all the functions for the Lock.

//............................Includes.................................//
//.....................................................................//
#include "Lock.h"

//...........................Functions.................................//
//.....................................................................//
/*
* Function:        Lock__InitializeLock
* description:     this fuction create new Lock sturct
* input:           none
* output:          Lock pointer
*/
struct Lock* Lock__InitializeLock() {
	struct Lock*	locks = NULL;
	BOOL			create_read = TRUE;
	BOOL			create_write = TRUE;

	locks = (struct Lock*)calloc(1, sizeof(struct Lock));
	if (!locks) {
		printf("Error: memory allocate was failed\n");
		return NULL;
	}
	locks->read_count = 0;
	locks->read_lock = NULL;
	locks->write_lock = NULL;

	/* create read lock mutex */
	locks->read_lock = CreateMutexA(NULL,			/* A pointer to a SECURITY_ATTRIBUTES structure. */
									FALSE,			/* the calling thread obtains initial ownership of the mutex object. */
									READ_MUTX);		/* The name of the mutex object. */
	if (!locks->read_lock) {
		printf("Error: CreateMutexA was failed: WinError 0x%X\n", GetLastError());
		create_read = FALSE;
	}

	locks->write_lock = CreateSemaphoreA(NULL,			/* A pointer to a SECURITY_ATTRIBUTES structure. */
										1,			    /* The initial count for the semaphore object. */
										1,		    	/* The maximum count for the semaphore object. */
										WRITE_SMP);	    /* The name of the semaphore object. */
	if (!locks->write_lock) {
		printf("Error: CreateSemaphoreA was failed: WinError 0x%X\n", GetLastError());
		create_write = FALSE;
	}

	if (create_read == FALSE || create_write == FALSE) {
		Lock__DestroyLock(&locks);
	}

	return locks;
}

/*
* Function:        Lock__read_lock
* description:     this fuction lock the Lock for reading
* input:           Lock pointer
* output:          lock_status
*/
int Lock__read_lock(struct Lock* locks) {
	DWORD	wait_code;
	BOOL	ret_val = TRUE;

	if (!locks) {
		return EXIT_FAILURE;
	}

	/* asks for read lock */
	wait_code = WaitForSingleObject(locks->read_lock, WAIT_TIME_READ_MSEC);
	if (wait_code != WAIT_OBJECT_0) {
		if (wait_code == WAIT_FAILED) {
			printf("Error: WaitForSingleObject was failed: WinError 0x%X\n", GetLastError());
			return EXIT_FAILURE;
		}
		else {
			printf("Error: WaitForSingleObject was failed: Unkown\n");
			return EXIT_FAILURE;
		}
	}

	locks->read_count++;

	if (locks->read_count == 1) {
		wait_code = WaitForSingleObject(locks->write_lock, WAIT_TIME_READ_MSEC);
		if (wait_code != WAIT_OBJECT_0) {
			if (wait_code == WAIT_FAILED) {
				printf("Error: WaitForSingleObject was failed: WinError 0x%X\n", GetLastError());
				return EXIT_FAILURE;
			}
			else {
				printf("Error: WaitForSingleObject was failed: Unkown\n");
				return EXIT_FAILURE;
			}
		}
	}

	ret_val = ReleaseMutex(locks->read_lock);
	if (ret_val == FALSE) {
		printf("Error: ReleaseMutex was failed: WinError 0x%X\n", GetLastError());
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}

/*
* Function:        Lock__read_realese
* description:     this fuction realese the Lock from reading
* input:           Lock pointer
* output:          realse_status
*/
int Lock__read_release(struct Lock* locks) {
	DWORD	wait_code;
	BOOL	ret_val = TRUE;

	if (!locks) {
		return EXIT_FAILURE;
	}

	wait_code = WaitForSingleObject(locks->read_lock, WAIT_TIME_READ_MSEC);
	if (wait_code != WAIT_OBJECT_0) {
		if (wait_code == WAIT_FAILED) {
			printf("Error: WaitForSingleObject was failed: WinError 0x%X\n", GetLastError());
			return EXIT_FAILURE;
		}
		else {
			printf("Error: WaitForSingleObject was failed: Unkown\n");
			return EXIT_FAILURE;
		}
	}

	locks->read_count--;

	if (locks->read_count == 0) {
		ret_val = ReleaseSemaphore(locks->write_lock, 1, NULL);
		if(ret_val == FALSE){
			printf("Error: ReleaseSemaphore was failed: Unkown\n");
			return EXIT_FAILURE;
		}
	}

	if (locks->read_lock) {
		ret_val = ReleaseMutex(locks->read_lock);
		if (ret_val == FALSE) {
			printf("Error: ReleaseMutex was failed: Unkown\n");
			return EXIT_FAILURE;
		}
	}
	return EXIT_SUCCESS;
}

/*
* Function:        Lock__write_lock
* description:     this fuction lock the Lock for writeing
* input:           Lock pointer
* output:          lock_status
*/
int Lock__write_lock(struct Lock* locks) {
	DWORD wait_code;

	if (!locks) {
		return EXIT_FAILURE;
	}

	wait_code = WaitForSingleObject(locks->write_lock, WAIT_TIME_WRITE_MSEC);
	if (wait_code != WAIT_OBJECT_0) {
		if (wait_code == WAIT_FAILED) {
			printf("Error: WaitForSingleObject was failed: WinError 0x%X\n", GetLastError());
			return EXIT_FAILURE;
		}
		else {
			printf("Error: WaitForSingleObject was failed: Unkown\n");
			return EXIT_FAILURE;
		}
	}

	return EXIT_SUCCESS;
}

/*
* Function:        Lock__write_realese
* description:     this fuction realese the Lock from writing
* input:           Lock pointer
* output:          realse_status
*/
int Lock__write_release(struct Lock* locks) {
	int ret_val = TRUE;

	if (!locks) {
		return EXIT_FAILURE;
	}

	ret_val = ReleaseSemaphore(locks->write_lock, 1, NULL);
	if (ret_val == FALSE) {
		printf("Error: SetEvent was failed: Unkown\n");
		return EXIT_FAILURE;
	}
	return EXIT_SUCCESS;
}

/*
* Function:        Lock__DestroyLock
* description:     this fuction realese the Lock struct
* input:           Lock pointer
* output:          exit_status
*/
int Lock__DestroyLock(struct Lock** locks) {
	HANDLE w_lock = NULL;
	int ret_val = EXIT_SUCCESS;

	if (!*locks) {
		return EXIT_FAILURE;
	}

	w_lock = (*locks)->write_lock;

	if ((*locks)->read_lock) {
		ret_val = CloseHandle((*locks)->read_lock);
		ASSERT("CloseHandle", ret_val);
	}

	if (w_lock) {
		ret_val = CloseHandle((*locks)->write_lock);
		ASSERT("CloseHandle", ret_val);
	}
	free(*locks);

	(*locks) = NULL;
	return EXIT_SUCCESS;
}
