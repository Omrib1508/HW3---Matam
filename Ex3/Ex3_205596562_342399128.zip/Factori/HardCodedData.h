/////////////////////////////////////////////////////////////////////////
///////////////////////// HardCodedData.h ///////////////////////////////
/////////////////////////////////////////////////////////////////////////

//info: This file contain all defines of the Father process.

#ifndef HARDCODEDDATA_H
#define HARDCODEDDATA_H

#define _CRT_SECURE_NO_WARNINGS
//............................Includes.................................//
//.....................................................................//

#include <Windows.h>

//............................Defines..................................//
//.....................................................................//

#define ARGUMENTS							5
#define MISSION_FILE						1
#define TASK_FILE							2
#define MISSION_NUM							3
#define THREADS_NUM							4

#define ZERO								48
#define NINE								57

#define EXIT_WAIT							2

#define SEC_2_MSEC							1000
#define MIN_2_SEC							60

#define WAIT_TIME_READ_MSEC					(20 * SEC_2_MSEC)
#define WAIT_TIME_WRITE_MSEC				(20 * SEC_2_MSEC)
#define WAIT_TIME_POP_QUEUE_MSEC			(40 * SEC_2_MSEC)
#define WAIT_QUEUE_FILL						(5 * SEC_2_MSEC)
#define WAIT_TIME_FOR_ALL_THREADS_MSEC		(10 * MIN_2_SEC * SEC_2_MSEC)

#define READ_MUTX							"Read_Lock_Mutex"
#define WRITE_SMP							"Write_Lock_Semaphore"
#define QUEUE_FILL_MUTX						"Queue_Fill_Mutex"


#define ASSERT(name, arg) do{																\
	if (!arg){																				\
		if(errno)																			\
			printf("Error: %s was failed: %s\n", name, strerror(errno));					\
		else if (GetLastError())															\
			printf("Error: %s was failed: WinError 0x%X\n", name, GetLastError());			\
		else																				\
			printf("Error: %s was failed: unknown error\n", name);							\
		return(EXIT_FAILURE);																\
	}																						\
} while (0);

#endif // !HARDCODEDDATA_H