/////////////////////////////////////////////////////////////////////////
//////////////////////////////// Queue.c ////////////////////////////////
/////////////////////////////////////////////////////////////////////////

//info: This Queue.c file of the Factori process is incharge for create
//      the Queue and arrange in array all the mission inside it.

//............................Includes.................................//
//.....................................................................//
#include "Queue.h"

//...........................Functions.................................//
//.....................................................................//
/*
* Function:        Queue__initializeQueue
* description:     this fuction create new Queue
* input:           none
* output:          Queue pointer
*/
struct Queue* Queue__initializeQueue(){
	struct Queue* queue = NULL;

	queue = (struct Queue*)calloc(1, sizeof(struct Queue));
	if (queue == NULL) {
		printf("Error: memory allocation failed!\n");
		return NULL;
	}

	queue->count = 0;
	queue->front = NULL;
	queue->rear = NULL;

	return queue;
}

/*
* Function:        Queue__Top
* description:     this fuction return the front element in Queue
* input:           Queue pointer
* output:          task element
*/
struct Q_node* Queue__Top(struct Queue* queue){
	
	if (!queue) {
		return NULL;
	}
	
	if (!queue->front) {
		return NULL;
	}
	return queue->front;
}

/*
* Function:        Queue__Pop
* description:     this fuction pops the front element in Queue
* input:           Queue pointer
* output:          task element
*/
struct Q_node* Queue__Pop(struct Queue* queue) {
	struct Q_node* temp = NULL;
	
	if (!queue) {
		return NULL;
	}

	if (Queue__Empty(queue)) {
		return NULL;
	}
	else{
		temp = queue->front;
		queue->front = queue->front->next;
		queue->count--;
		
		return temp;
	}
}

/*
* Function:        Queue__Push
* description:     this fuction push element to rear Queue
* input:           Queue__Push
* output:          exit_status
*/
int Queue__Push(struct Queue* queue,struct Q_node* task){
	
	if (!queue || !task) {
		return EXIT_FAILURE;
	}

	task->next = NULL;
	if (Queue__Empty(queue)) {
		queue->front = task;
		queue->rear = task;
	}
	else {
		queue->rear->next = task;
		queue->rear = task;
	}
	queue->count++;
	
	return EXIT_SUCCESS;
}

/*
* Function:        Queue__Empty
* description:     this fuction return if Queue is empty
* input:           Queue pointer
* output:          T/F
*/
int Queue__Empty(struct Queue* queue){
	if (queue->count == 0) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}

/*
* Function:        Queue__DestroyQueue
* description:     this fuction realese the Queue
* input:           Queue pointer
* output:          exit_status
*/
int Queue__DestroyQueue(struct Queue** queue){
	struct Q_node* iter;

	if (!*queue) {
		return EXIT_FAILURE;
	}

	while (!Queue__Empty(*queue)) {
		iter = Queue__Pop(*queue);
		free(iter);
	}

	free(*queue);
	*queue = NULL;
	return EXIT_SUCCESS;
}
