/////////////////////////////////////////////////////////////////////////
//////////////////////////// Factori.h //////////////////////////////////
/////////////////////////////////////////////////////////////////////////


//info: This file contain the Factori function declarion which used in
//      the proccess

#ifndef FACTORI_H
#define FACTORI_H

#pragma comment(lib, "Shlwapi.lib")
#define _CRT_SECURE_NO_WARNINGS
//............................Includes.................................//
//.....................................................................//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Windows.h>
#include <Shlwapi.h>

#include "HardCodedData.h"
#include "PrimeNum.h"
#include "Queue.h"
#include "Lock.h"

//............................Defines..................................//
//.....................................................................//

//...........................Structs...................................//
//.....................................................................//

struct FactoriArgs {
	char* missions_file_path;
	char* tasks_file_path;
	int missions_num;
	int threads_num;
}FactoriArgs;

struct QueueFill {
	BOOL fill_complite;
	LONG bytes;
	HANDLE h_queue_fill_mutex;
};

 struct ThreadParams {
	char* missions_file_path;
	char* tasks_file_path;
	int tasks_2_fill_queue;
	int missions_num;
	struct QueueFill* queue_fill;
	struct Queue* queue;
	struct Lock* locks;
};

 struct FactoriProcess {
	 struct FactoriArgs* factori_args;
	 struct ThreadParams* t_params;
	 HANDLE* h_threads;
 };

 enum Threads__return_code_t {
	Threads__CODE_SUCCESS,
	Threads__CODE_FAILURE,
	Threads__CODE_WAIT,
};


//...........................Functions.................................//
//.....................................................................//

int Factori__get_Factori(int argc, char* argv[], struct FactoriProcess* factori_process);

int Factori__create_threads(struct FactoriProcess* factori_process);

int Factori__init_Factori_process(struct FactoriProcess* factori_process, struct QueueFill* queue_fill);

int Factori__fill_Queue(struct ThreadParams* lpParams);

int Factori__read_num_mission_file(HANDLE h_mission_file,struct Q_node* task, int* mission_num);

DWORD WINAPI Factori__thread_fun(LPVOID param);

int Factori__wait_all_threads_2_finish(struct FactoriProcess* factori_process);

int Factori__clean_all(struct FactoriProcess* factori_process);

int Factori__open_file(HANDLE* h_file, char* file_path);

int Factori__wait_Queue_mutex(HANDLE queue_fill_mutex);

int Factori__release_Queue_mutex(HANDLE queue_fill_mutex);

int QueueFill__init_QueueFill(struct QueueFill* queue_fill);

int QueueFill__DestroyQueueFill(struct QueueFill* queue_fill);

#endif // !FACTORI_H