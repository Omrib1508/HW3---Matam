/////////////////////////////////////////////////////////////////////////
///////////////////////////// PrimeNum.c ////////////////////////////////
/////////////////////////////////////////////////////////////////////////

//info: This PrimeNum.c file handles all the functions that PrimeNum list
//      needs for create, add value to list and realese it.

//............................Includes.................................//
//.....................................................................//
#include "PrimeNum.h"

//...........................Functions.................................//
//.....................................................................//
/*
* Function:        PrimeNum_List__init_list
* description:     this fuction create the list
* input:           PrimeNum list
* output:          process exit code
*/
struct PrimeNum_node* PrimeNum_List__init_list() {
	struct PrimeNum_node* new_list;

	new_list = (struct PrimeNum_node*)calloc(1,sizeof(struct PrimeNum_node));
	if (!new_list) {
		printf("Error: memory allocation failed!\n");
		return NULL;
	}
	new_list->next = NULL;
	return new_list;
}

/*
* Function:        PrimeNum_List__add_node
* description:     this fuction add node to the list
* input:           PrimeNum list
* output:          process exit code
*/
struct PrimeNum_List* PrimeNum_List__add_node(struct PrimeNum_List* prime_list, int prime_num) {
	struct PrimeNum_node* iter;
	struct PrimeNum_node* prev = NULL;
	struct PrimeNum_node* new_node = NULL;

	if (!prime_list) {
		return NULL;
	}

	new_node = (struct PrimeNum_node*)calloc(1, sizeof(struct PrimeNum_node));
	if (!new_node) {
		printf("Error: memory allocation failed!\n");
		return NULL;
	}
	new_node->next = NULL;
	new_node->prime_num = prime_num;
 	new_node->prime_num_strlen = num_strlen(prime_num);

	if (prime_list->list == NULL) {
		prime_list->list = new_node;
		prime_list->list_size++;
		return prime_list;
	}

	if (new_node->prime_num <= prime_list->list->prime_num) {
		new_node->next = prime_list->list;
		prime_list->list = new_node;
		prime_list->list_size++;
		return prime_list;
	}
	iter = prime_list->list;
	
	while (iter != NULL && new_node->prime_num > iter->prime_num) {
		prev = iter;
		iter = iter->next;
	}
	
	if (prev != NULL) {
		prev->next = new_node;
		new_node->next = iter;
	}
	prime_list->list_size++;
	
	return prime_list;
}

/*
* Function:        PrimeNum_List__find_primes
* description:     this fuction find primes factors
* input:           PrimeNum list, number to prime
* output:          process exit code
*/
int PrimeNum_List__find_primes(struct PrimeNum_List* prime_list, int num_2_primes) {
	int num = num_2_primes;

	if (!prime_list) {
		return EXIT_FAILURE;
	}

	/* add number of 2s that divide num */
	while ((num % 2) == 0) {
		prime_list = PrimeNum_List__add_node(prime_list, 2);
		ASSERT("PrimeNum_List__add_node", prime_list);

		num = num / 2;
	}

	/* n must be odd */
	for (int i = 3; i <= sqrt(num); i = i + 2) {
		/* while i divides num */
		while (num % i == 0) {
			
			prime_list = PrimeNum_List__add_node(prime_list, i);
			ASSERT("PrimeNum_List__add_node", prime_list);

			num = num / i;
		}
	}
	/* is a prime greater then 2 */
	if (num > 2) {
		prime_list = PrimeNum_List__add_node(prime_list, num);
		ASSERT("PrimeNum_List__add_node", prime_list);
	}

	return EXIT_SUCCESS;
}

/*
* Function:        PrimeNum_List__list_string_length
* description:     this fuction return how many bytes need for list
* input:           PrimeNum list
* output:          list strings byte size
*/
int PrimeNum_List__list_string_length(struct PrimeNum_List* prime_list) {
	int						count = 0;
	struct PrimeNum_node*	iter;

	if (!prime_list) {
		return EXIT_FAILURE;
	}

	for (iter = prime_list->list; iter != NULL; iter = iter->next) {
			count += iter->prime_num_strlen;
	}
	return count;
}

/*
* Function:        PrimeNum_List__realese_list
* description:     this fuction realse node from the list
* input:           PrimeNum list
* output:          process exit code
*/
int PrimeNum_List__realese_list(struct PrimeNum_node* list) {
	struct PrimeNum_node* temp = NULL;
	
	while (list != NULL) {
		temp = list;
		list = list->next;
		free(temp);
	}
	return EXIT_SUCCESS;
}

/*
* Function:        PrimeNum_List__num_2_PrimeNum_list
* description:     this fuction take a number and return orderd prime num list
* input:           number for transform, PrimeNum list
* output:          PrimeNum ordered list
*/
struct PrimeNum_List* PrimeNum_List__num_2_PrimeNum_list(int num_2_primes){
	int						ret_val = EXIT_SUCCESS;
	struct PrimeNum_List*	s_list = NULL;

	s_list = (struct PrimeNum_List*)calloc(1,sizeof(struct PrimeNum_List));
	if (!s_list) {
		printf("Error: memory allocation failed!\n");
		return NULL;
	}
	s_list->list = NULL;

	ret_val = PrimeNum_List__find_primes(s_list, num_2_primes);
	if (ret_val) {
		printf("Error: can't find prime numbers correctlly\n");
		ret_val = PrimeNum_List__realese_list(s_list->list);
		if (ret_val) {
			printf("Error: also can't release list\n");
			free(s_list);
			return NULL;
		}
	}
	return s_list;
}


/*
* Function:        PrimeNum__create_output_line
* description:     this function create the output line
* input:           original number, PrimeNum list
* output:          output line
*/
char* PrimeNum__create_output_line(int num, struct PrimeNum_List* prime_list) {
	struct PrimeNum_node*		iter;
	size_t						line_len = 0, temp_len = 0;
	int							comma_num;
	int							list_byte_len;
	char*						line = NULL;
	char*						temp_line = NULL;
	BOOL						not_first_prime = FALSE;

	if (!prime_list) {
		return NULL;
	}

	comma_num = COMMA * (prime_list->list_size - 1);
	list_byte_len = PrimeNum_List__list_string_length(prime_list);
	line_len = THE_PRIME_FACTOR_OF__ARE + num_strlen(num) + comma_num + list_byte_len + END_LINE;
	line = (char*)calloc((line_len + 1), sizeof(char));
	if (!line) {
		printf("Error: memory allocate was failed\n");
		return NULL;
	}

	sprintf_s(line, line_len, "The prime factors of %d are: ", num);

	for (iter = prime_list->list; iter != NULL; iter = iter->next) {
		temp_len = (size_t)iter->prime_num_strlen + 1;

		if (not_first_prime) {
			/* if more than 1 prime add comma and space */
			temp_len += COMMA;
		}

		if (temp_len == 0) {
			break;
		}
		temp_line = (char*)calloc(temp_len, sizeof(char));
		if (!temp_line) {
			printf("Error: memory allocate was failed\n");
			return NULL;
		}

		if (not_first_prime) {
			sprintf_s(temp_line, temp_len, ", %d", iter->prime_num);
		}
		else {
			sprintf_s(temp_line, temp_len, "%d", iter->prime_num);
		}
		strcat(line, temp_line);

		free(temp_line);
		not_first_prime = TRUE;
	}

	line[line_len - 2] = '\r';
	line[line_len - 1] = '\n';

	return line;
}

/*
* Function:        PrimeNum__print_line_task_file
* description:     this function print line in end of task file
* input:           handle task file, line
* output:          exit status
*/
int PrimeNum__print_line_task_file(HANDLE* h_task_file, char** line) {
	HANDLE	h_task = *h_task_file;
	DWORD	get_val;
	int bytes = (int)strlen(*line);

	if (!h_task_file || !*line) {
		return EXIT_FAILURE;
	}

	get_val = SetFilePointer(h_task, 0, NULL, FILE_END);
	if (get_val == INVALID_SET_FILE_POINTER) {
		printf("Error: SetFilePointer was failed: WinError 0x%X\n", GetLastError());
		return EXIT_FAILURE;
	}
	
	get_val = WriteFile(h_task, *line, bytes, NULL, NULL);
	if (!get_val) {
		printf("Error: WriteFile was failed: WinError 0x%X\n", GetLastError());
		return EXIT_FAILURE;
	}

	free(*line);
	*line = NULL;

	return EXIT_SUCCESS;
}

/*
* Function:        num_strlen
* description:     this fuction take a number and return how much digit it has
* input:           number for transform, PrimeNum list
* output:          PrimeNum ordered list
*/
int num_strlen(int num) {
	int count = 1;

	while (num /= 10) {
		count++;
	}
	return count;
}