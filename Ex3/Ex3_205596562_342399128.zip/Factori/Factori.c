/////////////////////////////////////////////////////////////////////////
////////////////////////////// Factori.c ////////////////////////////////
/////////////////////////////////////////////////////////////////////////

//info: This Factori.c file of the Factori process is incharge of  
//      handling the process and incharge on his functions.

//............................Includes.................................//
//.....................................................................//
#include "Factori.h"

//............................Functions................................//
//.....................................................................//
/*
* Function:        Factori__get_Factori
* description:     this function get the Factori sturct
* input:           num of argument, argument array, Factori struct
* output:          exit status
*/
int Factori__get_Factori(int argc, char* argv[], struct FactoriProcess* factori_process) {
	int ret_val;
	struct FactoriArgs* p_factori_args = NULL;

	if (argc != ARGUMENTS) {
		printf("Error: invalid number of arguments(%d instead of %d)\n", (argc - 1), ARGUMENTS);
		exit(EXIT_FAILURE);
	}
	else {
		/* init structs */
		p_factori_args = (struct FactoriArgs*)calloc(1, sizeof(struct FactoriArgs));
		if (!p_factori_args) {
			printf("Error: memory allocate was failed\n");
			return EXIT_FAILURE;
		}

		/* get missions file path */
		p_factori_args->missions_file_path = argv[MISSION_FILE];
		ret_val = PathFileExistsA(p_factori_args->missions_file_path);
		if (!ret_val) {
			ASSERT("PathFileExistsA", ret_val);
		}

		/* get tasks file path */
		p_factori_args->tasks_file_path = argv[TASK_FILE];
		ret_val = PathFileExistsA(p_factori_args->tasks_file_path);
		if (!ret_val) {
			ASSERT("PathFileExistsA", ret_val);
		}

		/* get number of missions */
		p_factori_args->missions_num = strtol(argv[MISSION_NUM], NULL, 10);
		if (errno == ERANGE) {
			printf("Error: invalid number of missions\n");
			return EXIT_FAILURE;
		}

		/* get number of threads */
		p_factori_args->threads_num = strtol(argv[THREADS_NUM], NULL, 10);
		if (p_factori_args->threads_num < 1 || errno == ERANGE) {
			printf("Error: invalid number of threads\n");
			return EXIT_FAILURE;
		}

		factori_process->factori_args = p_factori_args;
		return EXIT_SUCCESS;
	}
}

/*
* Function:        Factori__create_threads
* description:     this function create the threads with the crtic function
* input:           factori process sturct
* output:          exit_status
*/
int Factori__create_threads(struct FactoriProcess* factori_process) {
	struct FactoriArgs*		p_factori_args = factori_process->factori_args;
	struct ThreadParams*	p_threads_params = factori_process->t_params;
	int						create_status = EXIT_SUCCESS;
	int						threads_mum = p_factori_args->threads_num;
	HANDLE*					p_h_threads = NULL;
	
	p_h_threads = (HANDLE*)calloc(threads_mum, sizeof(HANDLE));
	if (!p_h_threads) {
		printf("Error: memory did'nt allocated correctlly\n");
		return EXIT_FAILURE;
	}

	for (int i = 0; i < threads_mum; i++) {
		p_h_threads[i] = CreateThread(NULL,                                     /* default security attributes */
									0,                                          /* use default stack size */
									Factori__thread_fun,                        /* thread function */
									(LPVOID)&p_threads_params[i],               /* argument to thread func */
									0,                                          /* use default creation flags */
									NULL);                                      /* returns the thread id */
		if (!p_h_threads[i]) {
			printf("Error: thread[%d] was failed: WinError 0x%X\n", i, GetLastError());
			return EXIT_FAILURE;
		}
	}
	factori_process->h_threads = p_h_threads;
	return EXIT_SUCCESS;
}

/*
* Function:        Factori__init_Factori_process
* description:     this function initialize the Factori Process 
* input:           Facori procees struct
* output:          exit status
*/
int Factori__init_Factori_process(struct FactoriProcess* factori_process, struct QueueFill* queue_fill) {
	struct FactoriArgs*				p_factori_args = factori_process->factori_args;
	struct ThreadParams*			p_threads_params = NULL;
	struct Lock*					locks = NULL;
	struct Queue*					queue = NULL;
	HANDLE*							p_h_threads = NULL;
	int								threads_num = p_factori_args->threads_num;
	int								task_num = p_factori_args->missions_num;
	int								dev, remain;
	int								status = EXIT_SUCCESS;

	dev = task_num / threads_num;
	remain = task_num % threads_num;

	p_threads_params = (struct ThreadParams*)calloc(p_factori_args->threads_num, sizeof(struct ThreadParams));
	if (!p_threads_params) {
		printf("Error: memory allocate was failed\n");
		return EXIT_FAILURE;
	}

	locks = Lock__InitializeLock();
	if (!locks) {
		return EXIT_FAILURE;
	}

	queue = Queue__initializeQueue();
	if (!queue) {
		return EXIT_FAILURE;
	}

	status = QueueFill__init_QueueFill(queue_fill);
	if (!queue_fill || status) {
		return EXIT_FAILURE;
	}

	for (int i = 0; i < p_factori_args->threads_num; i++) {
		if (remain > 0) {
			p_threads_params[i].tasks_2_fill_queue = dev + 1;
			remain--;
		}
		else {
			p_threads_params[i].tasks_2_fill_queue = dev;
		}
		p_threads_params[i].locks = locks;
		p_threads_params[i].queue = queue;
		p_threads_params[i].queue_fill = queue_fill;
		p_threads_params[i].missions_num = p_factori_args->missions_num;
		p_threads_params[i].missions_file_path = p_factori_args->missions_file_path;
		p_threads_params[i].tasks_file_path = p_factori_args->tasks_file_path;
	}

	factori_process->t_params = p_threads_params;
	return EXIT_SUCCESS;
}

/*
* Function:        Factori__fill_Queue
* description:     this function fill the Queue nodes
* input:           threads params
* output:          exit status
*/
int Factori__fill_Queue(struct ThreadParams* lpParams) {
	struct Q_node*		task = NULL;
	struct Queue*		queue = lpParams->queue;
	struct QueueFill*	queue_fill = lpParams->queue_fill;
	int					task_data = 0;
	int					push_val;
	char				c;
	DWORD				ret_val;
	HANDLE				h_task_file = NULL;

	task = (struct Q_node*)calloc(1, sizeof(struct Q_node));
	if (!task) {
		printf("Error: memory wasn't allocated correctlly\n");
		return EXIT_FAILURE;
	}

	ret_val = Factori__open_file(&h_task_file, lpParams->tasks_file_path);
	if (ret_val || !h_task_file) {
		printf("Error: file didn't open correctlly\n");
		return EXIT_FAILURE;
	}

	ret_val = SetFilePointer(h_task_file, queue_fill->bytes, NULL, FILE_BEGIN);
	if (ret_val == INVALID_SET_FILE_POINTER) {
		printf("Error: SetFilePointer was failed: WinError 0x%X\n", GetLastError());
		return EXIT_FAILURE;
	}

	while (TRUE) {
		ret_val = ReadFile(h_task_file, &c, 1, NULL, NULL);
		if (!ret_val) {
			printf("Error: ReadFile was failed: WinError 0x%X\n", GetLastError());
			return EXIT_FAILURE;
		}
	
		if (c == '\r') {
			break;
		}

		if (c < ZERO || c > NINE) {
			return EXIT_FAILURE;
		}

		queue_fill->bytes++;
		task_data *= 10;
		task_data = task_data + c - ZERO;

		if (task_data < 0) {
			printf("Error: task byte number is invalid\n");
			return EXIT_FAILURE;
		}
	}
	task->data = task_data;
	task->next = NULL;
	
	queue_fill->bytes += 2;
	
	push_val = Queue__Push(queue, task);
	if (lpParams->queue->count == lpParams->missions_num) {
		queue_fill->fill_complite = TRUE;
	}
	
	ret_val = CloseHandle(h_task_file);
	if (!ret_val) {
		printf("Error: CloseHandle was failed: WinError 0x%X\n", GetLastError());
		return EXIT_FAILURE;
	}
	return EXIT_SUCCESS;
}

/*
* Function:        Factori__read_num_mission_file
* description:     this function get mission from mission file
* input:           handle mission file, Queue element, mission element
* output:          exit status
*/
int Factori__read_num_mission_file(HANDLE h_mission_file,struct Q_node* task, int* mission_num) {
	DWORD	get_val;
	char	c;

	(*mission_num) = 0;
	get_val = SetFilePointer(h_mission_file, task->data, NULL, FILE_BEGIN);
	if (get_val == INVALID_SET_FILE_POINTER) {
		printf("Error: SetFilePointer was failed: WinError 0x%X\n", GetLastError());
		return EXIT_FAILURE;
	}

	while (TRUE) {
		get_val = ReadFile(h_mission_file, &c, 1, NULL, NULL);
		if (!get_val) {
			printf("Error: ReadFile was failed: WinError 0x%X\n", GetLastError());
			return EXIT_FAILURE;
		}

		if (c == '\r') {
			break;
		}

		if (c < ZERO || c > NINE) {
			return EXIT_FAILURE;
		}

		(*mission_num) *= 10;
		(*mission_num) = (*mission_num) + c - ZERO;

		if (mission_num < 0) {
			printf("Error: mission number is invalid\n");
			return EXIT_FAILURE;
		}
	}
	return EXIT_SUCCESS;
}


/*
* Function:        Threads__Factori_thread_fun
* description:     this function handles the wait time of the semaphore
* input:           thread parameters array
* output:          exitcode
*/
DWORD WINAPI Factori__thread_fun(LPVOID param) {
	struct	ThreadParams*		lpParam = (struct ThreadParams*)(param);
	int							Thread_status = Threads__CODE_SUCCESS;
	int							exit_stats = EXIT_SUCCESS;
	int							mission_num = 0;
	char*						output_line = NULL;
	struct PrimeNum_List*		prime_list = NULL;
	struct QueueFill*			queue_fill = lpParam->queue_fill;
	struct Q_node*				task = NULL;
	HANDLE						h_mission_file = NULL;
	HANDLE						h_task_file = NULL;
	BOOL						open_val, close_val;

	open_val = Factori__open_file(&h_task_file, lpParam->tasks_file_path);
	if (open_val) {
		printf("Error: can't open missions file\n");
	}
	do { /* threads help main thread to fill Queue */
		if (lpParam->tasks_2_fill_queue > 0) {
			Thread_status = Factori__wait_Queue_mutex(queue_fill->h_queue_fill_mutex);
			if (Thread_status == Threads__CODE_FAILURE) { break; }

			if (Thread_status != Threads__CODE_WAIT) {
				Thread_status = Factori__fill_Queue(lpParam);
				if (Thread_status) { break; }
				lpParam->tasks_2_fill_queue--;

				Thread_status = Factori__release_Queue_mutex(queue_fill->h_queue_fill_mutex);
				if (Thread_status) { break; }
			}
		}
		else {
			break;
		}
	} while (TRUE);

	do {/* wait threads to fill Queue */
		if (queue_fill->fill_complite == TRUE) {
			break;
		}
		Sleep(WAIT_QUEUE_FILL);
	} while (TRUE);

	open_val = Factori__open_file(&h_mission_file, lpParam->missions_file_path);
	if (open_val) {
		printf("Error: can't open missions file\n");
	}
	
	do {/* do missions */
		/* Pop task from Queue */
		Thread_status = Factori__wait_Queue_mutex(queue_fill->h_queue_fill_mutex);
		if (Thread_status != Threads__CODE_SUCCESS) { break; }

		task = Queue__Pop(lpParam->queue);
		
		Thread_status = Factori__release_Queue_mutex(queue_fill->h_queue_fill_mutex);
		if (Thread_status == Threads__CODE_FAILURE) { break; }
		
		if (!task) {
			Thread_status = Threads__CODE_SUCCESS;
			break;
		}


		/* get mission from task file */
		Thread_status = Lock__read_lock(lpParam->locks);
		if (Thread_status == Threads__CODE_FAILURE) { break; }

		Thread_status = Factori__read_num_mission_file(h_mission_file, task, &mission_num);
		
		exit_stats = Lock__read_release(lpParam->locks);
		if (exit_stats == EXIT_FAILURE) {
			Thread_status = Threads__CODE_FAILURE;
		}

		if (Thread_status == Threads__CODE_FAILURE) { break; }

		/* get PrimeNum List from number and create line*/
		prime_list = PrimeNum_List__num_2_PrimeNum_list(mission_num);
		output_line = PrimeNum__create_output_line(mission_num, prime_list);
		if (!output_line || !prime_list) {
			break;
		}

		/* get mission from task file */
		Thread_status = Lock__write_lock(lpParam->locks);
		if (Thread_status == Threads__CODE_FAILURE) { break; }

		Thread_status = PrimeNum__print_line_task_file(&h_mission_file, &output_line);
		
		exit_stats = Lock__write_release(lpParam->locks);
		if (exit_stats == EXIT_FAILURE) {
			Thread_status = Threads__CODE_FAILURE;
		}

	} while (Thread_status == Threads__CODE_SUCCESS);

	if (h_mission_file) {
		close_val = CloseHandle(h_mission_file);
		if (!close_val) {
			printf("Error: CloseHandle was failed: WinError 0x%X\n", GetLastError());
			Thread_status = Threads__CODE_FAILURE;
		}
	}

	if (h_task_file) {
		close_val = CloseHandle(h_task_file);
		if (!close_val) {
			printf("Error: CloseHandle was failed: WinError 0x%X\n", GetLastError());
			Thread_status = Threads__CODE_FAILURE;
		}
	}
	
	if (output_line) {
		free(output_line);
	}
	if (prime_list) {
		free(prime_list);
		prime_list = NULL;
	}
	if (task) {
		free(task);
	}

	if (Thread_status != Threads__CODE_SUCCESS) {
		ExitThread(Threads__CODE_FAILURE);
	}
	ExitThread(Threads__CODE_SUCCESS);
}

/*
* Function:        Factori__wait_all_threads_2_finish
* description:     this function wait all threads for finish there's functions
* input:           factori process sturct
* output:          wait status
*/
int Factori__wait_all_threads_2_finish(struct FactoriProcess* factori_process) {
	DWORD	wait_code, exit_code;
	BOOL	ret_val = EXIT_SUCCESS;
	struct FactoriArgs* p_factori_args = factori_process->factori_args;
	struct ThreadParams* p_threads_params = factori_process->t_params;
	HANDLE* p_h_threads = factori_process->h_threads;

	wait_code = WaitForMultipleObjects(p_factori_args->threads_num,                         /* nubmer of threads to wait */
										p_h_threads,                                        /* threads handle */
										TRUE,                                               /* wait for all threads */
										WAIT_TIME_FOR_ALL_THREADS_MSEC);                    /* wait time */
	if (wait_code != WAIT_OBJECT_0) {
		if (wait_code == WAIT_FAILED) {
			printf("Error: WaitForMultipleObjects was failed: WinError 0x%X\n", GetLastError());
			return EXIT_FAILURE;
		}
		else {
			printf("Error: WaitForMultipleObjects was failed: Unkown\n");
			return EXIT_FAILURE;
		}
	}
	else {
		for (int i = 0 ; i < p_factori_args->threads_num ; i++) {
			ret_val = GetExitCodeThread(p_h_threads[i], &exit_code);
			if (!ret_val) {
				printf("Error: GetExitCodeThread was failed: WinError 0x%X\n", GetLastError());
				return EXIT_FAILURE;
			}
			if (exit_code != Threads__CODE_SUCCESS) {
				printf("Thread number[%d] was failed\n", i);
				return EXIT_FAILURE;
			}
		}
	}
	return EXIT_SUCCESS;
}

/*
* Function:        Factori__wait_all_threads_2_finish
* description:     this function wait all threads for finish there's functions
* input:           factori process sturct
* output:          wait status
*/
int Factori__clean_all(struct FactoriProcess* factori_process) {
	int clean_status = EXIT_SUCCESS;
	BOOL close_status = TRUE;
	struct FactoriArgs* p_factori_args = factori_process->factori_args;
	struct ThreadParams* p_threads_params = factori_process->t_params;
	HANDLE* p_h_threads = factori_process->h_threads;


	/* close and destory Threads Params */
	clean_status = Lock__DestroyLock(&p_threads_params->locks);
	if (clean_status) {
		printf("Error: Destroy Locks was failed\n");
		return EXIT_FAILURE;
	}
	clean_status = Queue__DestroyQueue(&p_threads_params->queue);
	if (clean_status) {
		printf("Error: Destroy Queue was failed\n");
		return EXIT_FAILURE;
	}
	close_status = QueueFill__DestroyQueueFill(p_threads_params->queue_fill);
	if (clean_status) {
		printf("Error: Destroy Locks was failed\n");
		return EXIT_FAILURE;
	}

	/* close Threads and free Threads handle */
	for (int i = 0; i < p_factori_args->threads_num; i++) {
		close_status = CloseHandle(p_h_threads[i]);
		ASSERT("CloseHandle", close_status);
	}
	if (p_h_threads) {
		free(p_h_threads);
	}
	if (p_threads_params) {
		free(p_threads_params);
	}

	return EXIT_SUCCESS;
}

/*
* Function:        Factori__open_file
* description:     this function Create a new file to share with all Threads
* input:           outfile_handle, outfile_path
* output:          create status
*/
int Factori__open_file(HANDLE* h_file, char* file_path) {
	*h_file = CreateFileA(file_path,                                 // name of the write
						GENERIC_WRITE | GENERIC_READ,               // open for writing or reading
						FILE_SHARE_WRITE | FILE_SHARE_READ,         // share file for write or read
						NULL,                                       // default security
						OPEN_EXISTING,                              // open file if existing
						FILE_ATTRIBUTE_NORMAL,        // normal file
						NULL);                        // no attr. template

	if (h_file == INVALID_HANDLE_VALUE) {
		printf("Error: CreateFileA was failed: WinError 0x%X\n", GetLastError());
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}

/*
* Function:        Factori__wait_Queue_mutex
* description:     this function use wait mutex for queue to fill
* input:           mutex_handle
* output:          create status
*/
int Factori__wait_Queue_mutex(HANDLE queue_fill_mutex) {
	DWORD	wait_code;

	wait_code = WaitForSingleObject(queue_fill_mutex, WAIT_TIME_POP_QUEUE_MSEC);
	if (wait_code != WAIT_OBJECT_0) {
		if (wait_code == WAIT_FAILED) {
			printf("Error: WaitForSingleObject was failed: WinError 0x%X\n", GetLastError());
			return EXIT_FAILURE;
		}
		else if (wait_code == WAIT_TIMEOUT) {
			return EXIT_WAIT;
		}
		else {
			printf("Error: WaitForSingleObject was failed: Unkown\n");
			return EXIT_FAILURE;
		}
	}
	return EXIT_SUCCESS;
}

/*
* Function:        Factori_release_Queue_mutex
* description:     this function Create a new file to share with all Threads
* input:           outfile_handle, outfile_path
* output:          create status
*/
int Factori__release_Queue_mutex(HANDLE queue_fill_mutex) {
	int get_val;

	get_val = ReleaseMutex(queue_fill_mutex);
	if (get_val == FALSE) {
		printf("Error: ReleaseMutex was failed: Unkown\n");
		return EXIT_FAILURE;
	}
	return EXIT_SUCCESS;
}

/*
* Function:        QueueFill__init_QueueFill
* description:     this function Create QueueFill Struct
* input:           none
* output:          QueueFill strcut
*/
int QueueFill__init_QueueFill(struct QueueFill* queue_fill) {
	queue_fill->h_queue_fill_mutex = CreateMutexA(NULL,                /* A pointer to a S_A structure */
												FALSE,                 /* the calling thread obtains initial ownership of the mutex object */
												QUEUE_FILL_MUTX);      /* The name of the semaphore object. */
	if (!queue_fill->h_queue_fill_mutex) {
		printf("Error: CreateMutexA was failed: WinError 0x%X\n", GetLastError());
		return EXIT_FAILURE;
	}

	queue_fill->fill_complite = FALSE;
	queue_fill->bytes = 0;

	return EXIT_SUCCESS;
}

/*
* Function:        QueueFill__DestroyQueueFill
* description:     this function destroy the QueueFill Struct
* input:           QueueFill strcut
* output:          destroy status
*/
int QueueFill__DestroyQueueFill(struct QueueFill* queue_fill) {
	int ret_val = EXIT_SUCCESS;

	if (!queue_fill) {
		return EXIT_FAILURE;
	}

	if (queue_fill->h_queue_fill_mutex) {
		ret_val = CloseHandle(queue_fill->h_queue_fill_mutex);
		ASSERT("CloseHandle", ret_val);
	}
	return EXIT_SUCCESS;
}