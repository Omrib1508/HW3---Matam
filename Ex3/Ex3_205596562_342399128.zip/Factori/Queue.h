/////////////////////////////////////////////////////////////////////////
/////////////////////////////// Queue.h /////////////////////////////////
/////////////////////////////////////////////////////////////////////////


//info: This file contain the Queue struct and all  function declarion
//      that responsible for monipulate the Queue.

#ifndef QUEUE_H
#define QUEUE_H

#define _CRT_SECURE_NO_WARNINGS
//............................Includes.................................//
//.....................................................................//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "HardCodedData.h"

//............................Defines..................................//
//.....................................................................//

//...........................Structs...................................//
//.....................................................................//

struct Q_node {
	int data;
	struct Q_node* next;
};

struct Queue{
	int count;
	struct Q_node* front;
	struct Q_node* rear;
};

//...........................Functions.................................//
//.....................................................................//

struct Queue* Queue__initializeQueue();

struct Q_node* Queue__Top(struct Queue* queue);

struct Q_node* Queue__Pop(struct Queue* queue);

int Queue__Push(struct Queue* queue,struct Q_node* task);

int Queue__Empty(struct Queue* queue);

int Queue__DestroyQueue(struct Queue** queue);

#endif // !QUEUE_H
