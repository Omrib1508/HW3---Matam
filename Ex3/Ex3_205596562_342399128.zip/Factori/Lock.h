/////////////////////////////////////////////////////////////////////////
/////////////////////////////// Lock.h //////////////////////////////////
/////////////////////////////////////////////////////////////////////////


//info: This file contain the Queue struct and all  function declarion
//      that responsible for monipulate the Queue.

#ifndef LOCK_H
#define LOCK_H

#define _CRT_SECURE_NO_WARNINGS
//............................Includes.................................//
//.....................................................................//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Windows.h>

#include "HardCodedData.h"
//............................Defines..................................//
//.....................................................................//

//...........................Structs...................................//
//.....................................................................//
struct Lock {
	HANDLE read_lock;
	HANDLE write_lock;
	int read_count;
};

//...........................Functions.................................//
//.....................................................................//

struct Lock* Lock__InitializeLock();

int Lock__read_lock(struct Lock* locks);

int Lock__read_release(struct Lock* locks);

int Lock__write_lock(struct Lock* locks);

int Lock__write_release(struct Lock* locks);

int Lock__DestroyLock(struct Lock** locks);

#endif // !LOCK_H
