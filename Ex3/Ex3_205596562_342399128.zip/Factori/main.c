/////////////////////////////////////////////////////////////////////////
///////////////////////////////// main.c ////////////////////////////////
/////////////////////////////////////////////////////////////////////////

//info: This main.c of the Factori process is incharge of reading the
//      input arguments, set missions into queue and print it to the file.

//............................Includes.................................//
//.....................................................................//
#include "Factori.h"

//...........................Functions.................................//
//.....................................................................//
/*
* Function:        main
* description:     the main function does the Factori process
* input:           number of arguments, array of argument
* output:          process exit code
*/
int main(int argc, char* argv[]) {
	int							get_val = EXIT_SUCCESS;
	struct FactoriProcess*		factori_process = NULL;
	struct QueueFill			queue_fill = { 0 };

	factori_process = (struct FactoriProcess*)calloc(1,sizeof(struct FactoriProcess));
	if (!factori_process) {
		printf("Error: factori_process memory wasn't allocated correctlly\n");
		exit(EXIT_FAILURE);
	}


	/* get Factori arguments from user */
	get_val = Factori__get_Factori(argc, argv, factori_process);
	
	/* initialize Factori Process */
	get_val = Factori__init_Factori_process(factori_process, &queue_fill);

	/* create Factori threads and start function */
	get_val = Factori__create_threads(factori_process);

	/* wait for all thread to finish */
	get_val = Factori__wait_all_threads_2_finish(factori_process);
	
	/* clean all memory and data structres */
	get_val = Factori__clean_all(factori_process);
	
	if (factori_process) {
		free(factori_process);
	}

	if (!get_val) {
		printf("Finish Process!\n");
	}
	return get_val;
}