/////////////////////////////////////////////////////////////////////////
//////////////////////////// PrimeNum.h /////////////////////////////////
/////////////////////////////////////////////////////////////////////////


//info: This file contain PrimeNum list struct and all  function 
//      declarion that responsible for dismantle a number to primes 
//      numbers and arrange them in order from small to bigest one.

#ifndef PRIMENUM_H
#define PRIMENUM_H

#define _CRT_SECURE_NO_WARNINGS
//............................Includes.................................//
//.....................................................................//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "HardCodedData.h"
//............................Defines..................................//
//.....................................................................//

#define THE_PRIME_FACTOR_OF__ARE			27
#define END_LINE							2
#define COMMA								2

//...........................Structs...................................//
//.....................................................................//

struct PrimeNum_List {
	struct PrimeNum_node* list;
	int list_size;
}PrimeNum_List;

struct PrimeNum_node {
	int prime_num;
	int prime_num_strlen;
	struct PrimeNum_node* next;
};
//...........................Functions.................................//
//.....................................................................//

struct PrimeNum_node* PrimeNum_List__init_list();

struct PrimeNum_List* PrimeNum_List__add_node(struct PrimeNum_List* prime_list, int prime_num);

int PrimeNum_List__find_primes(struct PrimeNum_List* prime_list, int num_2_primes);

int PrimeNum_List__list_string_length(struct PrimeNum_List* prime_list);

int PrimeNum_List__realese_list(struct PrimeNum_node* list);

struct PrimeNum_List* PrimeNum_List__num_2_PrimeNum_list(int num_2_primes);

char* PrimeNum__create_output_line(int num,struct PrimeNum_List* prime_list);

int PrimeNum__print_line_task_file(HANDLE* h_task_file, char** line);

int num_strlen(int num);

#endif // !PRIMENUM_h
